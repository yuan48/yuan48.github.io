对于网页的整体说明

index 首页
bbs 论坛界面-资料分享
classwork 班级界面
utils 实用界面-翻译、视频/文章爬虫
user 用户个人界面




# index
* 首页图、bbs导航、快捷翻译栏目、文章推荐个人空间